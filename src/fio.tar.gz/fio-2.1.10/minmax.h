#ifndef FIO_MIN_MAX_H
#define FIO_MIN_MAX_H

#ifndef min
#define min(a, b)	((a) < (b) ? (a) : (b))
#endif
#ifndef max
#define max(a, b)	((a) > (b) ? (a) : (b))
#endif

#endif
